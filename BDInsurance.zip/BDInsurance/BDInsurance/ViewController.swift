//
//  ViewController.swift
//  BDInsurance
//
//  Created by Richard Robinson on 4/23/20.
//  Copyright © 2020 com.Robinson-Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

